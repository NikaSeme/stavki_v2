"""CatBoost models for STAVKI - Preferred over LightGBM."""

from .catboost_model import CatBoostModel

__all__ = ["CatBoostModel"]
